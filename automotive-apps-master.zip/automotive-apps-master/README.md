# automotive-apps

npm install (frontend then backend)

npm run serve (front end)
node server.js (back end)
